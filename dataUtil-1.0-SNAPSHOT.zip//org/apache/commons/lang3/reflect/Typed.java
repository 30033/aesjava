package org.apache.commons.lang3.reflect;

import java.lang.reflect.Type;

public interface Typed<T> {
   Type getType();
}
