package org.apache.commons.lang3.builder;

public interface Builder<T> {
   T build();
}
