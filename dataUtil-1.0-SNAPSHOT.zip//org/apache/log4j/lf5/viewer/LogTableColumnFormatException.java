package org.apache.log4j.lf5.viewer;

public class LogTableColumnFormatException extends Exception {
   private static final long serialVersionUID = 6529165785030431653L;

   public LogTableColumnFormatException(String message) {
      super(message);
   }
}
