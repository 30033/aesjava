package org.apache.log4j.spi;

public interface OptionHandler {
   void activateOptions();
}
