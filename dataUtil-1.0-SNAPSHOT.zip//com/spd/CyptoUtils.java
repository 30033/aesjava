package com.spd;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

public class CyptoUtils implements Encryption {
   private Logger logger = Logger.getLogger(CyptoUtils.class);
   private static final String AES = "AES";
   private static final String encoding = "UTF-8";
   private String cryptPath = "/data/key/secret.txt";
   private String debugPath = "D:\\Download\\secret.txt";
   private static final String stitcher = "_";
   private boolean debug = false;
   private String password;
   private String version;
   private Map<String, String> map = null;

   public CyptoUtils() {
   }

   public CyptoUtils(Boolean debug) {
      this.debug = debug;
   }

   public CyptoUtils(String version, Boolean debug) {
      this.version = version;
      this.debug = debug;
   }

   public void init() throws Exception {
      File file = null;
      if (this.debug) {
         file = new File(this.debugPath);
      } else {
         file = new File(this.cryptPath);
      }

      if (!file.exists()) {
         throw new Exception("秘钥文件不存在");
      } else {
         List<String> list = FileUtils.readLines(file);
         if (null != list && list.size() > 0) {
            this.map = new HashMap();
            Iterator var3 = list.iterator();

            while(var3.hasNext()) {
               String str = (String)var3.next();
               String[] strs = str.split("\\|");
               this.map.put(strs[0], strs[1]);
            }

            if (StringUtils.isNotEmpty(this.version)) {
               this.password = (String)this.map.get(this.version);
            } else {
               String currentStr = (String)list.get(list.size() - 1);
               String[] cstrs = currentStr.split("\\|");
               this.version = cstrs[0];
               this.password = cstrs[1];
            }
         }

         if (StringUtils.isEmpty(this.password)) {
            this.logger.error("没有获取到 " + this.version + " 对应的密码");
            throw new Exception("没有获取到 " + this.version + " 对应的密码");
         }
      }
   }

   public String encrypt(String content) {
      try {
         if (StringUtils.isNotEmpty(content) && content.length() == 11) {
            Cipher cipher = this.getCipher(this.password, "ENCRYPT");
            byte[] byteContent = content.getBytes("UTF-8");
            byte[] result = cipher.doFinal(byteContent);
            String hexStr = ParseSystemUtil.parseByte2HexStr(result);
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append(this.version).append("_").append(hexStr).append("_").append(this.getIndexStr(content));
            return stringBuffer.toString();
         }

         this.logger.error("需要加密的电话号码不能为空或者长度不是11位");
      } catch (UnsupportedEncodingException var7) {
         var7.printStackTrace();
      } catch (BadPaddingException var8) {
         var8.printStackTrace();
      } catch (IllegalBlockSizeException var9) {
         var9.printStackTrace();
      } catch (Exception var10) {
         var10.printStackTrace();
      }

      return "";
   }

   public String decrypt(String content) {
      try {
         String[] contents = content.split("_");
         String currentVersion = contents[0];
         if (this.map.containsKey(currentVersion)) {
            this.password = (String)this.map.get(currentVersion);
         }

         String cipherText = contents[1];
         byte[] byteContent = ParseSystemUtil.parseHexStr2Byte(cipherText);
         Cipher cipher = this.getCipher(this.password, "DECRYPT");
         byte[] result = cipher.doFinal(byteContent);
         return new String(result);
      } catch (BadPaddingException var8) {
         var8.printStackTrace();
      } catch (IllegalBlockSizeException var9) {
         var9.printStackTrace();
      }

      return null;
   }

   private Cipher getCipher(String password, String key) {
      KeyGenerator keyGenerator = null;

      try {
         keyGenerator = KeyGenerator.getInstance("AES");
         SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG", "SUN");
         secureRandom.setSeed(password.getBytes());
         keyGenerator.init(128, secureRandom);
         SecretKey secretKey = keyGenerator.generateKey();
         byte[] enCodeFormat = secretKey.getEncoded();
         SecretKeySpec secretKeySpec = new SecretKeySpec(enCodeFormat, "AES");
         Cipher cipher = Cipher.getInstance("AES");
         if (key.equals("DECRYPT")) {
            cipher.init(2, secretKeySpec);
         } else {
            cipher.init(1, secretKeySpec);
         }

         return cipher;
      } catch (NoSuchAlgorithmException var9) {
         var9.printStackTrace();
      } catch (NoSuchPaddingException var10) {
         var10.printStackTrace();
      } catch (InvalidKeyException var11) {
         var11.printStackTrace();
      } catch (NoSuchProviderException var12) {
         var12.printStackTrace();
      }

      return null;
   }

   private String getIndexStr(String content) {
      return content.length() > 4 ? content.substring(content.length() - 4) : "";
   }

   public static void main(String[] args) throws Exception {
      String filePath = "";
      if (args.length > 0) {
         filePath = args[0];
      }

      String outPath = "";
      if (args.length > 1) {
         outPath = args[1];
      }

      if (!"".equals(filePath) && !"".equals(outPath)) {
         String type = "1";
         if (args.length > 2) {
            type = args[2];
         }

         String pattern = "";
         if (args.length > 3) {
            pattern = args[3];
         }

         String index = "";
         if (args.length > 4) {
            index = args[4];
         }

         String version = "";
         if (args.length > 5) {
            version = args[5];
         }

         boolean debug = false;
         if (args.length > 6) {
            debug = Boolean.parseBoolean(args[6]);
         }

         try {
            File inputFile = new File(filePath);
            List<String> contents = FileUtils.readLines(inputFile);
            Iterator var10 = contents.iterator();

            while(var10.hasNext()) {
               String content = (String)var10.next();
               String currentStr = content;
               String[] strs = null;
               int current = 0;
               if (StringUtils.isNotEmpty(pattern)) {
                  strs = content.split(pattern);
                  if (StringUtils.isNotEmpty(index)) {
                     current = Integer.parseInt(index);
                     currentStr = strs[current - 1];
                  } else {
                     currentStr = strs[current];
                  }
               }

               CyptoUtils cyptoUtils = new CyptoUtils(version, debug);
               cyptoUtils.init();
               String resut = "";
               if ("1".equals(type)) {
                  resut = cyptoUtils.encrypt(currentStr);
               } else {
                  resut = cyptoUtils.decrypt(currentStr);
               }

               if (StringUtils.isNotEmpty(resut)) {
                  if (StringUtils.isNotEmpty(pattern)) {
                     if (StringUtils.isNotEmpty(index)) {
                        strs[current - 1] = resut;
                     } else {
                        strs[current] = resut;
                     }

                     resut = convert2String(strs, pattern);
                  }

                  writeFile(outPath, resut);
               }
            }
         } catch (Exception var17) {
            var17.printStackTrace();
         }

      } else {
         throw new Exception("输入文件和输出文件必须存在");
      }
   }

   private static String convert2String(String[] arrs, String pattern) {
      StringBuffer stringBuffer = new StringBuffer();

      for(int i = 0; i < arrs.length; ++i) {
         stringBuffer.append(arrs[i]);
         if (i != arrs.length - 1) {
            stringBuffer.append(pattern);
         }
      }

      return stringBuffer.toString();
   }

   public static void writeFile(String fileFullPath, String content) {
      FileOutputStream fos = null;

      try {
         fos = new FileOutputStream(fileFullPath, true);
         fos.write(content.getBytes());
         fos.write("\r\n".getBytes());
      } catch (IOException var12) {
         var12.printStackTrace();
      } finally {
         if (fos != null) {
            try {
               fos.flush();
               fos.close();
            } catch (IOException var11) {
               var11.printStackTrace();
            }
         }

      }

   }
}
