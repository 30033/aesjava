package com.spd;

import java.security.MessageDigest;

public class Md5Test {
   public static void main(String[] args) throws Exception {
      String message = "352100076062415";
      MessageDigest messageDigest = MessageDigest.getInstance("MD5");
      byte[] md5byte = messageDigest.digest(message.getBytes());
      String md5str = bytes2Hex(md5byte);
      System.out.println(md5str);
   }

   public static String bytes2Hex(byte[] bytes) {
      StringBuffer result = new StringBuffer();

      try {
         for(int i = 0; i < bytes.length; ++i) {
            int temp = bytes[i];
            if (temp < 0) {
               temp += 256;
            }

            if (temp < 16) {
               result.append("0");
            }

            result.append(Integer.toHexString(temp));
         }
      } catch (Exception var4) {
         var4.printStackTrace();
      }

      return result.toString();
   }
}
