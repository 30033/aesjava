package com.spd;

public interface Encryption {
   String encrypt(String var1);

   String decrypt(String var1);
}
